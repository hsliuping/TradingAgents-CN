

global user_id
global default_socket
