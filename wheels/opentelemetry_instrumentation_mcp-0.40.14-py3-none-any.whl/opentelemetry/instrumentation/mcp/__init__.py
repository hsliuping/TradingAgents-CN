from opentelemetry.instrumentation.mcp.version import __version__
from opentelemetry.instrumentation.mcp.instrumentation import McpInstrumentor

__all__ = ["McpInstrumentor", "__version__"]
