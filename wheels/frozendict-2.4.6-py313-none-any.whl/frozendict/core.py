# this provides compatibility for older pickles
# created on a python-only implementation that
# specifically mention frozendict.core.frozendict

# noinspection PyUnresolvedReferences
from frozendict import frozendict
