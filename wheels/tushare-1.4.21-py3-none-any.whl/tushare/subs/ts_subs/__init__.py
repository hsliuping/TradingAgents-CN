"""
# 作 者：84028
# 时 间：2024/2/28 20:47
# tsdpsdk
"""

from .subscribe import TsSubscribe
