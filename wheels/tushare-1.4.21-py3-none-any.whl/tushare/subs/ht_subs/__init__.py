# -*- coding:utf-8 -*-
'''
Created on 2021年9月24日

@author: Administrator
'''

from .subscribe import InsightSubscribe
